package client;

import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Scanner;
import java.nio.file.Path; 
import java.nio.file.Paths; 

public class FileClient {
    public static void main(String[] args) throws Exception{
        Socket clientSocket = null;
        OutputStream outToServer = null;
        InputStream inFromServer = null;
        
        while(true)
        {    
        Scanner userinput = new Scanner(System.in);
        System.out.print("==> ");
        String commandLine = userinput.nextLine();      
        String[] userVariables = commandLine.split(" ");
        System.out.println(Arrays.toString(userVariables));
        String returnline = " \r\n ";

        
        if(userVariables[0].toUpperCase().equals("OPEN"))
        {
            String server = userVariables[1];
            int port = Integer.parseInt(userVariables[2]);
            clientSocket = new Socket(server, port);
            System.out.println("Connected to server");        
        }
        
        else if(userVariables[0].toUpperCase().equals("GET"))
        {
            String sourcepath = userVariables[1];
            String destination = userVariables[2];
            
            outToServer = clientSocket.getOutputStream();
            inFromServer = clientSocket.getInputStream();  
            
            outToServer.write(("GET " + sourcepath + returnline).getBytes());
            
            byte[] bytes = new byte[255];
            inFromServer.read(bytes);
            String serverResponse = new String(bytes);
            System.out.println("Recieved--------\n" + serverResponse);
            
            
            String[] returnVariables = serverResponse.split("\r\n");
            System.out.println("\n" + Arrays.toString(returnVariables));
            
            String responseType = returnVariables[0];
            int responseIndicator = Integer.parseInt(responseType.substring(5,8));
            
            
            if(responseIndicator == 200)
            {
                System.out.println("Confirmation 200: File received");
                String serverData = returnVariables[2];
                byte[] serverDataBytes = serverData.getBytes();
                int contentLength = serverData.length(); // Not necessary
                String[] sourceVariables = sourcepath.split("/");
                String filename = sourceVariables[sourceVariables.length - 1];
                Path destinationpath = Paths.get(destination + filename + "");
                System.out.println("Saving to " + destinationpath);
                
                Files.createFile(destinationpath);
                Files.write(destinationpath, serverDataBytes);             
            }
            
            else if(responseIndicator == 404)
            {
                System.out.println("Error 404: File not found");
            }
            
        }
        
        else if(userVariables[0].toUpperCase().equals("CLOSE"))
        {
            outToServer.write(("CLOSE" + returnline).getBytes());
            System.out.println("Closing connection");
            clientSocket.close();
        }    
        
        
        }
       
    }
    
}