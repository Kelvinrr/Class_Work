package server;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileServer {
	
	
	public final static int DEFAULT_PORT = 9998;
	
	private ServerSocket server_socket;
	private Socket client_socket;
	private boolean server_is_stopped = false;
	
	/**
	 * @throws IOException 
	 * 
	 */
	public void run() throws IOException {
		byte[] receive_data = new byte[1024];             
	    byte[] send_data 	= new byte[1024];   
	    
	    InputStream input_stream  = null;
	    OutputStream output_stream = null;
	    
	    String[] socket_arg = null;
	    
	    // Try to start the server on port -------------------------------------
	    try {
	    	server_socket = new ServerSocket(DEFAULT_PORT);
	    }catch (Exception e){
	    	System.out.println("Failed to open server on port " + DEFAULT_PORT);
	    	System.exit(-1);
	    }
	    // ---------------------------------------------------------------------
	    
	    try {
		    
	    	System.out.println("Server is running...");
		    while (!server_is_stopped) {
			    	String file_contents = ""; 
			    	
				    // accept the client --------------------------------------------
				    client_socket = server_socket.accept();
					input_stream = client_socket.getInputStream();
					output_stream = client_socket.getOutputStream();
				    
					System.out.println("\nAccepted Client:");
					System.out.println(client_socket + "\n");
					// --------------------------------------------------------------
					
					// read data from client socket ---------------------------------
					input_stream.read(receive_data);
					String data = new String(receive_data);
					System.out.println("Recieved: " + data);
					
					socket_arg = data.split(" ");
					
					if(socket_arg[0].equalsIgnoreCase("GET")) {
						String[] contents = socket_arg[1].split("/");
						file_contents = contents[contents.length-1];
						
						System.out.println("Sending: " + ("Data 200 OK \r\ncontent-length: " + 
													file_contents.length() + "\r\n" + 
													file_contents));
						
						output_stream.write(("Data 200 OK \r\ncontent-length: " + 
													file_contents.length() + "\r\n" + 
													file_contents).getBytes());
					}
					
					else if(socket_arg[0].equalsIgnoreCase("CLOSE")) {
						System.out.println("Closing Connection: " + client_socket);
						server_socket.close();
						client_socket.close();
					}
					
					else {
						System.out.println("Unknown Request...");
					}
		    	}  // end of server loop 
		    
	    } catch (IOException e) {
		    	output_stream.write("DATA 404 Not found /r/n".getBytes());
		} catch (Exception e) {
		    	System.out.println("Failed to accept client " + client_socket + " with server socket " + server_socket);
		}
	}
	
	
	/**
	 * 
	 * @param path
	 * @param encoding
	 * @return input ASCII file as String
	 * @throws IOException
	 */
	static String readFile(String path) throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return new String(encoded);
	}
	
	
	public static void main(String[] args) {
		FileServer filserver = new FileServer();
		try {
			filserver.run();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
